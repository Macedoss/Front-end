
const perguntas = [
    {
        titulo: "Qual filme ganhou o Oscar de Melhor Filme em 2020?",
        respostas: ["Vingadores: Ultimato", "Parasita", "1917", "Coringa"],
        correta: 1 
    },
    {
        titulo: "Quem é o vilão do filme 'IT'?",
        respostas: ["Motoqueiro Fantasma", "Jason", "Pennywise", "Frankstein"],
        correta: 2 
    },
    {
        titulo: "No filme 'Matrix', qual pílula Neo escolhe?",
        respostas: ["Azul", "Verde", "Vermelha", "Amarela"],
        correta: 2 
    },
    {
        titulo: "Qual é a frase clássica do Tio Ben para o Homem-Aranha?",
        respostas: [
            "Com grandes poderes, vêm grandes responsabilidades",
            "A força esteja com você",
            "Ao infinito e além",
            "Eu sou seu pai"
        ],
        correta: 0 
    }
];


let indiceAtual = 0; 
let pontuacao = 0;   
let nomeJogador = ""; 


const formCadastro = document.getElementById('form-cadastro');
const sectionCadastro = document.getElementById('cadastro-section');
const sectionQuiz = document.getElementById('area-quiz');


formCadastro.addEventListener('submit', function(event) {
    event.preventDefault(); 

    
    nomeJogador = document.getElementById('usuario').value;

   
    sectionCadastro.classList.add('hidden');
    sectionQuiz.classList.remove('hidden');

   
    carregarPergunta();
});


function carregarPergunta() {
    
    if (indiceAtual < perguntas.length) {
        const perguntaDaVez = perguntas[indiceAtual];

        
        let htmlContent = `
            <div class="quiz-container">
                <h2>Questão ${indiceAtual + 1} de ${perguntas.length}</h2>
                <p class="pergunta-texto">${perguntaDaVez.titulo}</p>
                <div class="opcoes-container">
        `;

       
        perguntaDaVez.respostas.forEach((opcao, index) => {
            htmlContent += `
                <button class="btn-opcao" onclick="checarResposta(${index})">
                    ${opcao}
                </button>
            `;
        });

        htmlContent += `</div></div>`;
        
       
        sectionQuiz.innerHTML = htmlContent;
    } else {
       
        mostrarResultado();
    }
}


function checarResposta(indiceEscolhido) {
    const perguntaDaVez = perguntas[indiceAtual];

    
    if (indiceEscolhido === perguntaDaVez.correta) {
        pontuacao++; 
        alert("Acertou! 🎬"); 
    } else {
        alert(`Errou! A resposta certa era: ${perguntaDaVez.respostas[perguntaDaVez.correta]}`);
    }

   
    indiceAtual++;
    carregarPergunta();
}


function mostrarResultado() {
    
    const mensagemRanking = definirNivel(pontuacao);

    sectionQuiz.innerHTML = `
        <div class="resultado-final">
            <h2>Fim de Jogo, ${nomeJogador}!</h2>
            <p>Sua pontuação foi:</p>
            <div class="placar-destaque">${pontuacao} / ${perguntas.length}</div>
            <p class="nivel-ranking">Nível: <strong>${mensagemRanking}</strong></p>
            <button onclick="location.reload()">Jogar Novamente</button>
        </div>
    `;
}


function definirNivel(pontos) {
    if (pontos === 4) return "🏆 Cinéfilo ";
    if (pontos === 3) return "🍿 Pipoca de Ouro ";
    if (pontos === 2) return "😐 Espectador Casual ";
    return "😴 Dormiu no Cinema ";
}